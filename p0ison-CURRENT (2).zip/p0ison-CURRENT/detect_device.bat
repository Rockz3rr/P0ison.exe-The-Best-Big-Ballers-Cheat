@echo off
REM Shared helper: detects whether the Quest is connected wired (USB) or
REM wireless (adb over TCP/IP), and sets two variables for the caller to use:
REM   ADB_SERIAL       - pass to "adb -s %ADB_SERIAL%"
REM   FRIDA_HOST_ARGS  - pass to frida, e.g. "frida %FRIDA_HOST_ARGS% <PID> ..."
REM Prefers a wired connection if both are present (more stable for injection).
REM FRIDA_HOST_ARGS is always "-U" either way - frida's adb transport works
REM the same over a USB cable or over "adb connect ip:port", so there's no
REM real need for a separate wireless-specific frida connection mode.
REM No "setlocal" in this file on purpose - callers "call" this script, which
REM runs in their own environment, so the variables set here stay visible
REM after the call returns.

set "ADB_SERIAL="
set "FRIDA_HOST_ARGS="
set "_WIRED="
set "_WIRELESS="

for /f "skip=1 tokens=1,2" %%a in ('adb devices') do call :classify "%%a" "%%b"

if defined _WIRED (
    set "ADB_SERIAL=%_WIRED%"
    set "FRIDA_HOST_ARGS=-U"
    echo [*] Device connection: wired ^(%_WIRED%^)
    exit /b 0
)

if defined _WIRELESS (
    set "ADB_SERIAL=%_WIRELESS%"
    REM "-U" (adb transport), not "-H ip:27042" - frida's -U flag works
    REM through adb regardless of whether the underlying adb link is a USB
    REM cable or adb-over-TCP (which is exactly what "adb connect ip:5555"
    REM sets up), by tunneling through the SAME adb connection already used
    REM for the "ps -A"/"pull" calls elsewhere in these scripts. "-H ip:27042"
    REM instead opens an independent raw TCP connection straight to
    REM frida-server's port, which can go stale on Wi-Fi even while adb
    REM itself is still fine - that's what caused "can't connect to remote
    REM server" despite adb clearly working.
    set "FRIDA_HOST_ARGS=-U"
    echo [*] Device connection: wireless ^(%_WIRELESS%^)
    exit /b 0
)

echo [!] No connected device found ^(wired or wireless^). Plug in USB or connect over adb first.
exit /b 1

:classify
if not "%~2"=="device" goto :eof
REM No trailing "$" anchor here on purpose - findstr's $ doesn't match past
REM the trailing \r that "echo | findstr" leaves in the piped line under
REM cmd.exe, so a "$"-anchored version of this pattern NEVER matches and
REM every wireless (IP:port) serial silently misclassifies as wired,
REM which then sends FRIDA_HOST_ARGS=-U (USB) for a device that's only
REM reachable over Wi-Fi. Matching just the "digits.digits.digits.digits:digits"
REM prefix is unambiguous enough for real adb serials.
echo %~1 | findstr /r "^[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*:[0-9][0-9]*" >nul
if errorlevel 1 (
    set "_WIRED=%~1"
) else (
    set "_WIRELESS=%~1"
)
goto :eof
