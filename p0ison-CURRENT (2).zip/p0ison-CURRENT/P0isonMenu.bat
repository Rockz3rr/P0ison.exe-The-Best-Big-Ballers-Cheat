@echo off
cd /d "%~dp0"

rem Menu script to load.
rem
rem This now points at the OBFUSCATED build, not the readable source, and that is
rem deliberate even though this is your own testing launcher. The reason the menu
remade by a skidder was originally taken is not that the .ts was hard to read - it
rem is not hard at all - but that the readable file was the one being opened, and
rem shipped in the folder. Testing the exact artefact a buyer gets is the only way
rem to know the obfuscated one still works, and it removes the temptation to point
rem this back at the source.
rem
rem To debug, change this to bigballers_menu.ts, and change it back before you
rem build or send anything. node make-release.js refuses to ship a launcher that
rem points at the source.
set "MENU_SCRIPT=P0isonmenu.js"

if not exist "%MENU_SCRIPT%" (
    echo [!] %MENU_SCRIPT% is missing.
    echo [!] Build it with:  node build\minify.js
    pause
    exit /b 1
)

echo [*] Detecting device...
call "%~dp0detect_device.bat"
if errorlevel 1 (
    pause
    exit /b 1
)

echo [*] Checking Frida server...
set "HOST_FRIDA_VERSION="
set "DEVICE_FRIDA_VERSION="

for /f "delims=" %%i in ('frida --version 2^>nul') do if not defined HOST_FRIDA_VERSION set "HOST_FRIDA_VERSION=%%i"
if not defined HOST_FRIDA_VERSION (
    echo [!] Frida CLI was not found on this PC.
    pause
    exit /b 1
)

adb -s %ADB_SERIAL% shell "su -c 'test -x /data/local/tmp/frida-server'" >nul 2>&1
if errorlevel 1 (
    echo [!] /data/local/tmp/frida-server is missing or is not executable on the Quest.
    echo [!] Install the arm64 frida-server matching host version %HOST_FRIDA_VERSION%.
    pause
    exit /b 1
)

for /f "delims=" %%i in ('adb -s %ADB_SERIAL% shell "su -c '/data/local/tmp/frida-server --version'" 2^>nul') do if not defined DEVICE_FRIDA_VERSION set "DEVICE_FRIDA_VERSION=%%i"
if not defined DEVICE_FRIDA_VERSION (
    echo [!] Could not read the Quest frida-server version.
    pause
    exit /b 1
)

if /i not "%HOST_FRIDA_VERSION%"=="%DEVICE_FRIDA_VERSION%" (
    echo [!] Frida version mismatch: PC=%HOST_FRIDA_VERSION%, Quest=%DEVICE_FRIDA_VERSION%.
    echo [!] Replace /data/local/tmp/frida-server with the matching arm64 build.
    pause
    exit /b 1
)

adb -s %ADB_SERIAL% shell "su -c 'ss -ltn | grep -q :27042'" >nul 2>&1
if errorlevel 1 (
    echo [*] Starting frida-server %DEVICE_FRIDA_VERSION% on the Quest...
    adb -s %ADB_SERIAL% shell "su -c '/data/local/tmp/frida-server -D'" >nul 2>&1
    if errorlevel 1 (
        echo [!] Could not start frida-server on the Quest.
        pause
        exit /b 1
    )
    timeout /t 1 /nobreak >nul
)

adb -s %ADB_SERIAL% shell "su -c 'ss -ltn | grep -q :27042'" >nul 2>&1
if errorlevel 1 (
    echo [!] frida-server did not open port 27042.
    pause
    exit /b 1
)

echo [+] Frida %DEVICE_FRIDA_VERSION% is ready.

rem Wait for the game rather than checking once.
rem
rem This is what makes "start the bat, then open the game" reliable. The checks
rem above take several seconds, so the game is often still launching when this
rem point is reached - previously that was a coin flip, and launching the game a
rem moment too late meant the bat gave up and quit. Now it polls, so the order
rem genuinely does not matter: open the game whenever, and it attaches as soon as
rem the process exists.
rem
rem 90 seconds is long enough for a cold start on a Quest over Wi-Fi without
rem leaving someone staring at a dead window for minutes.
set PID=
set /a WAITED=0
:waitforgame
for /f "tokens=2" %%i in ('adb -s %ADB_SERIAL% shell "ps -A | grep com.dogelabs.bigballersbasketball"') do set PID=%%i
if not "%PID%"=="" goto gamefound
if %WAITED% geq 90 goto gameneverran
rem Short pause between polls so this does not hammer adb, and a progress line
rem that is rewritten in place rather than scrolling one line per second.
<nul set /p "=Waiting for Big Ballers to start... %WAITED%s/90s"
ping -n 2 127.0.0.1 >nul
set /a WAITED+=1
goto waitforgame

:gameneverran
echo.
echo [!] Big Ballers Basketball did not start within 90 seconds.
echo     Open it on the Quest and try again.
pause
exit /b 1

:gamefound
echo.
echo [+] Found PID: %PID% (waited %WAITED%s)
frida %FRIDA_HOST_ARGS% %PID% -l "frida-il2cpp-bridge.js" -l "%MENU_SCRIPT%"
pause
